var express = require("express"),
    consign = require("consign"),
    bodyParser = require("body-parser"),
    validator = require("express-validator");
//morgan = require("morgan"),
moment = require('moment'),
    Sequelize = require("sequelize"),
    logger = require("../log/logger.js");


module.exports = function () {
    var app = express();
    app.use(bodyParser.urlencoded({ extended: true, limit: '5mb' }));
    app.use(bodyParser.json({ limit: '5mb' }));
    app.use(validator());

    //Middleware for Routers
    app.use(function (request, response, next) {
        console.log("Recurso: %s - %s", request.method, request.url);
        logger.request({ request: request.body, method: request.method, url: request.url, date: moment() });
        if ((request.method == "GET" && request.url.indexOf("/user/img")==0) ||
            (request.method == "PUT" && request.url == "/user/autentic") ||
            (request.method == "PUT" && request.url == "/user/login") ||
            (request.method == "POST" && request.url == "/user/resetpassword") ||
            request.method == "POST" && request.url == "/user") {
            next();
        } else {
            var jwt = require("../utils/security");
            jwt.isTokenValid(request.headers.authorization, function (IsValid, code, message, u) {
                if (IsValid) {
                    next();
                } else {
                    logger.error({ result: message, method: request.method, url: request.url });
                    response.status(code).json({ message: message });
                }
            });
        }
    });

    consign()
        .include("routers")
        .then("controllers")
        .then("service")
        .then("log")
        .then("utils")
        .into(app);

    //Middleware for Error 400
    app.use(function (request, response, next) {
        var erro = new Error("Not Found");
        console.log({ result: erro, method: request.method, url: request.url });
        erro.status = 404;
        erro.menssage = "not found";
        next(erro);
    });

    //Middleware for Error 500
    app.use(function (erro, request, response, next) {
        logger.route({ error: erro, method: request.method, url: request.url, date: moment() });
        console.log('----------------------------------');
        console.log(erro.stack);
        response.status(erro.status || 500).json({ erro: erro.menssage });
        console.log('----------------------------------');
    });
    return app;
}