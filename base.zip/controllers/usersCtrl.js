let models = require("..//models"),
    logger = require("../log/logger.js"),
    jwtSecurity = require("../utils/security"),
    moment = require('moment'),
    crypto = require("crypto"),
    email = require('../service/email');


function usersCtrl(app) {
    this._app = app;
}
//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.createUser = function (request, response) {
    let data = request.body;
    try {
        data.photo = Date.now().toString();
        data.password = crypto.createHash('md5').update(data.password).digest("hex");

        models.users.create(data, { raw: true }).then(function (user) {
            let data_user = { id_user: user.dataValues.id_user, nickname: user.dataValues.nickname, password: user.dataValues.password };
            jwtSecurity.generateToken(data_user, function (token, expires) {
                logger.success({ result: data.nickname, method: request.method, url: request.url, token: token, expires: expires, code: 110, date: moment() });
                response.status(201).json({ status: true, token: token, expires: expires, code: 110 });
            });
        }).catch(function (error) {
            if (error.original.errno == 1062) { //field unique or primary duplicated
                logger.database({ result: error, data: data, method: request.method, url: request.url, code: 112, date: moment() });
                response.status(400).json({ status: false, message: "nickname already exists", code: 112 });
            } else {
                logger.database({ result: error, data: data, method: request.method, url: request.url, code: 113, date: moment() });
                response.status(400).json({ status: false, error, code: 113 });
            }
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 115, date: moment() });
        response.status(500).json({ status: false, ex, code: 115 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.autenticUser = function (request, response) {
    let data = request.body;
    try {
        data.password = crypto.createHash('md5').update(data.password).digest("hex");

        models.users.findOne({ where: { nickname: data.nickname, password: data.password, active: 'Y' }, raw: true }).then(function (user) {
            if (user) {
                let data_user = { id_user: user.id_user, nickname: user.nickname, password: user.password };
                jwtSecurity.generateToken(data_user, function (token, expires) {
                    logger.success({ result: data.nickname, method: request.method, url: request.url, token: token, expires: expires, code: 120, date: moment() });
                    response.status(200).json({ status: true, token: token, expires: expires, code: 120 });
                });
            } else {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 121, date: moment() });
                response.status(400).json({ status: true, code: 121 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: data, method: request.method, url: request.url, code: 123, date: moment() });
            response.status(400).json({ status: false, error, code: 123 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 125, date: moment() });
        response.status(500).json({ status: false, ex, code: 125 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.updateUser = function (request, response) {
    let data = request.body,
        usertoken = jwtSecurity.getUserfromToken(request),
        options = {};
    try {
        data.password = crypto.createHash('md5').update(data.password).digest("hex");

        if (data.password) {
            if (data.password != usertoken.password) {
                options.password = data.password;
                data.password = usertoken.password;
            }
        }
        if (data.email) {
            options.email = data.email;
        }
        if (data.region) {
            options.region = data.region;
        }
        if (data.platform) {
            options.platform = data.platform;
        }
        models.users.update(options, { where: { nickname: data.nickname, password: data.password, id_user: usertoken.id_user, active: 'Y' } }, { raw: true }).then(function (user) {
            if (user > 0) {
                let data_user = { id_user: usertoken.id_user, nickname: data.nickname, password: data.password };
                jwtSecurity.generateToken(data_user, function (token, expires) {
                    logger.success({ result: data.nickname, method: request.method, url: request.url, token: token, expires: expires, code: 130, date: moment() });
                    response.status(200).json({ status: true, token: token, expires: expires, code: 130 });
                });
            } else {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 136, date: moment() });
                response.status(400).json({ status: true, message: "Operation can't applied", code: 136 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: data, method: request.method, url: request.url, code: 133, date: moment() });
            response.status(400).json({ status: false, error, code: 133 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 135, date: moment() });
        response.status(500).json({ status: false, ex, code: 135 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.imageCreateUser = function (request, response) {
    let dados = { local: './perfil/' },
        user = jwtSecurity.getUserfromToken(request);
    try {
        let imgFile = new this._app.utils.imageProcess();
        models.users.findOne({ where: { id_user: user.id_user, active: 'Y' }, raw: true }).then(function (user) {
            if (user) {
                dados.name = user.photo;
                imgFile.saveImg(request, dados);
                logger.success({ result: user.nickname, method: request.method, url: request.url, code: 140, date: moment() });
                response.status(200).json({ status: true, code: 140 });
            } else {
                logger.success({ method: request.method, url: request.url, code: 141, date: moment() });
                response.status(400).json({ status: true, code: 141 });
            }
        }).catch(function (error) {
            logger.database({ result: error, method: request.method, url: request.url, code: 143, date: moment() });
            response.status(400).json({ status: false, error, code: 143 });
        })
    } catch (ex) {
        logger.error({ result: ex, method: request.method, url: request.url, code: 145, date: moment() });
        response.status(500).json({ status: false, ex, code: 145 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.getImageUser = function (request, response) {
    let appDir = require('path').dirname(require.main.filename);
    try {
        models.users.findOne({ where: { nickname: request.params.nickname }, raw: true }).then(function (user) {
            if (user) {
                logger.success({ result: user.nickname, method: request.method, url: request.url, code: 150, date: moment() });
                response.sendFile(appDir + '/perfil/' + user.photo + '.jpg');
            } else {
                logger.success({ result: request.params.nickname, method: request.method, url: request.url, code: 151, date: moment() });
                response.status(400).json({ status: true, code: 151 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: request.params.nickname, method: request.method, url: request.url, code: 153, date: moment() });
            response.status(400).json({ status: false, error, code: 153 });
        });
    } catch (ex) {
        logger.error({ result: ex, data: request.params.nickname, method: request.method, url: request.url, code: 155, date: moment() });
        response.status(500).json({ status: false, ex, code: 155 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.getUser = function (request, response) {
    let data = request.body;
    try {
        data.password = crypto.createHash('md5').update(data.password).digest("hex");

        models.users.findOne({
            where: { nickname: data.nickname, password: data.password },
            attributes: ['id_user', 'nickname', 'email', 'platform', 'region', 'active'], raw: true
        }).then(function (user) {
            if (user) {
                if (user.active == 'N') {
                    models.users.update({ active: 'Y' }, { where: { nickname: data.nickname, password: data.password } }, { raw: true }).then(function (user_update) {
                        if (user_update > 0) {
                            let data_user = { id_user: user.id_user, nickname: user.nickname, password: user.password };
                            jwtSecurity.generateToken(data_user, function (token, expires) {
                                logger.success({ result: data.nickname, method: request.method, url: request.url, token: token, expires: expires, code: 160, date: moment() });
                                delete user['id_user'];
                                response.status(200).json({ status: true, user, token: token, expires: expires, code: 160 });
                            });
                        } else {
                            logger.success({ result: data.nickname, method: request.method, url: request.url, code: 161, date: moment() });
                            response.status(400).json({ status: true, code: 161 });
                        }
                    });
                } else {
                    let data_user = { id_user: user.id_user, nickname: user.nickname, password: user.password };
                    jwtSecurity.generateToken(data_user, function (token, expires) {
                        logger.success({ result: data.nickname, method: request.method, url: request.url, token: token, expires: expires, code: 160, date: moment() });
                        response.status(200).json({ status: true, user, token: token, expires: expires, code: 160 });
                    });
                }
            } else {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 161, date: moment() });
                response.status(400).json({ status: true, code: 161 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: data, method: request.method, url: request.url, code: 123, date: moment() });
            response.status(400).json({ status: false, error, code: 163 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 125, date: moment() });
        response.status(500).json({ status: false, ex, code: 165 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.getUserList = function (request, response) {
    var funcao = models.sequelize;
    let nickname = request.params.nickname;
    let user = jwtSecurity.getUserfromToken(request);
    try {
        models.users.findAll({
            where: { nickname: { $like: nickname + "%", $ne: user.nickname }, active: 'Y' },
            attributes: ['nickname', 'photo'], raw: true
        }).then(function (user) {
            if (user) {
                logger.success({ result: nickname, method: request.method, url: request.url, code: 170, date: moment() });
                response.status(200).json({ status: true, user, code: 170 });
            } else {
                logger.success({ result: nickname, method: request.method, url: request.url, code: 171, date: moment() });
                response.status(400).json({ status: true, code: 171 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: nickname, method: request.method, url: request.url, code: 173, date: moment() });
            response.status(400).json({ status: false, error, code: 173 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: nickname, method: request.method, url: request.url, code: 175, date: moment() });
        response.status(500).json({ status: false, ex, code: 175 });
    }
}

//---------------------------------------------------------------------------------------------------------------------//
usersCtrl.prototype.deleteUser = function (request, response) {
    let data = request.body;
    try {
        data.password = crypto.createHash('md5').update(data.password).digest("hex");

        models.users.update({ active: 'N' }, { where: { nickname: data.nickname, password: data.password } }, { raw: true }).then(function (user) {
            if (user > 0) {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 180, date: moment() });
                response.status(200).json({ status: true, code: 180 });
            } else {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 186, date: moment() });
                response.status(400).json({ status: true, message: "Operation can't applied", code: 186 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: data, method: request.method, url: request.url, code: 183, date: moment() });
            response.status(400).json({ status: false, error, code: 183 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 185, date: moment() });
        response.status(500).json({ status: false, ex, code: 185 });
    }
}

usersCtrl.prototype.resetPassword = function (request, response) {
    let data = request.body;
    try {
        models.users.findAll({
            where: { nickname: data.nickname },
            attributes: ['email'],  raw: true }).then(function (user) {
            if (user.length > 0) {
                email.sendEmailReset(user[0].email, function(emailResponse){
                    logger.success({ result: data.nickname, method: request.method, url: request.url, code: 180, date: moment() });
                    response.status(200).json({ status: true, code: 180 })
                    
                }, function(emailError){
                    logger.success({ result: data.nickname, method: request.method, url: request.url, code: 186, date: moment() });
                    response.status(400).json({ status: true, message: "Operation can't applied", code: 186 });
                });
            } else {
                logger.success({ result: data.nickname, method: request.method, url: request.url, code: 186, date: moment() });
                response.status(400).json({ status: true, message: "Operation can't applied", code: 186 });
            }
        }).catch(function (error) {
            logger.database({ result: error, data: data, method: request.method, url: request.url, code: 183, date: moment() });
            response.status(400).json({ status: false, error, code: 183 });
        })
    } catch (ex) {
        logger.error({ result: ex, data: data, method: request.method, url: request.url, code: 185, date: moment() });
        response.status(500).json({ status: false, ex, code: 185 });
    }
}



module.exports = function () {
    return usersCtrl;
}