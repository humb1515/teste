var nodemailer = require('nodemailer');


module.exports = {
        sendEmailReset:function(email, callbackSuccess, callbackError) {
            var transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'noreplayapp1328@gmail.com',
                    pass: '123456aqwetg'
                }
            });
            var mailOptions = {
                from: 'noreplay-base@base.com',
                to: email,
                subject: 'Forget Password?',
               // text: 'Ainda precisa configurar um email com um domino nosso para não usar o gmail :D'
               html: '<strong>Nova Senha</strong><p>Sua nova senha será.....<p><h1>Pikachu</h1></p></p>'
            };


            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log(error);
                    callbackError(error)
                } else {
                    console.log('Email sent: ' + info.response);
                    callbackSuccess(info.response)
                }
            });
        },
}
