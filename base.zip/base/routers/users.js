module.exports = function (app) {

    //post       - criar usuário
    //put        - autenticar usuário
    //put        - login usuário (ativa usuário caso desativado)
    //put        - editar usuário (exceto nickname)
    //post       - salvar imagem de perfil
    //post       - captura imagem de perfil
    //delete     - desativa usuário

    //put        - resetar senha

    //get        - lista de usuários

    /**
     * Criar usuário
     * body - json
     * nickname * password * email * platform * region
     * 
     */
    app.post('/user', function (request, response) {
        request.assert("nickname","Field 'nickname' can't be null").notEmpty();
        request.assert("password","Field 'password' can't be null").notEmpty();
        request.assert("platform","Field 'platform' can't be null").notEmpty();
        request.assert("region","Field 'region' can't be null").notEmpty();
        let errors = request.validationErrors();
        if(errors){
            logger.params({ params: errors, method: request.method , url: request.url, date: moment()});
            response.status(400).send(errors);
        }else{
            var usersController = new app.controllers.usersCtrl(app);
            usersController.createUser(request, response);
        }
    });

    /**
     * autentica usuário
     * body - json
     * nickname * password
     * 
     */
    app.put('/user/autentic', function(request, response){
        request.assert("nickname","Field 'nickname' can't be null").notEmpty();
        request.assert("password","Field 'password' can't be null").notEmpty();
        let errors = request.validationErrors();
        if(errors){
            logger.params({ params: errors, method: request.method , url: request.url, date: moment()});
            response.status(400).send(errors);
        }else{
            var usersController = new app.controllers.usersCtrl(app);
            usersController.autenticUser(request, response);
        }
    });

    /**
     * login usuário, pegar todas as informações do usuário
     * body - json
     * nickname * password
     * 
     */
    app.put('/user/login', function(request, response){
        request.assert("nickname","Field 'nickname' can't be null").notEmpty();
        request.assert("password","Field 'password' can't be null").notEmpty();
        let errors = request.validationErrors();
        if(errors){
            logger.params({ params: errors, method: request.method , url: request.url, date: moment()});
            response.status(400).send(errors);
        }else{
            var usersController = new app.controllers.usersCtrl(app);
            usersController.getUser(request, response);
        }
    });

    /**
     * Alterar usuário
     * body - json
     * nickname - não faz update * password * email * platform * region
     * 
     */
    app.put('/user', function (request, response) {
        request.assert("nickname","Field 'nickname' can't be null").notEmpty();
        let errors = request.validationErrors();
        if(errors){
            logger.params({ params: errors, method: request.method , url: request.url, date: moment()});
            response.status(400).send(errors);
        }else{
            var usersController = new app.controllers.usersCtrl(app);
            usersController.updateUser(request, response);
        }
    });

    /**
     * Salvar imagem usuário
     * body - octet-stream
     * 
     */
    app.post('/user/img', function(request, response){
        var usersController = new app.controllers.usersCtrl(app);
            usersController.imageCreateUser(request, response);
    });

   /**
     * Capturar imagem usuário
     * param * nickname
     * 
     */
    app.get('/user/img/:nickname', function(request, response){
        var usersController = new app.controllers.usersCtrl(app);
            if(request.params.nickname){
                usersController.getImageUser(request, response);
            }else{
                logger.params({ params: request.params, method: request.method , url: request.url, date: moment()});
                response.status(400).send("params nickname necessary");
            }
    });

    /**
     * Lista todos os usuários pelo nickname - operador like ao final
     * param * nickname
     * nickname = teste
     * result [teste001, teste, testeTeste, teste_alternativo, teste003, teste...]
     */
    app.get('/user/:nickname', function(request, response){
        var usersController = new app.controllers.usersCtrl(app);
        if(request.params.nickname){
            usersController.getUserList(request, response);
        }else{
            logger.params({ params: request.params, method: request.method , url: request.url, date: moment()});
            response.status(400).send("params nickname necessary");
        }
    });

    /**
     * Capturar imagem usuário
     * body * nickname * password
     * 
     */
    app.delete('/user', function(request, response){
        request.assert("nickname","Field 'nickname' can't be null").notEmpty();
        request.assert("password","Field 'password' can't be null").notEmpty();
        let errors = request.validationErrors();
        if(errors){
            logger.params({ params: errors, method: request.method , url: request.url, date: moment()});
            response.status(400).send(errors);
        }else{
            var usersController = new app.controllers.usersCtrl(app);
            usersController.deleteUser(request, response);
        }
    });
}