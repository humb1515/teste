var winston = require('winston');
var fs = require('fs');

if (!fs.existsSync('log')) {
    fs.mkdirSync('log');
}
const myCustomLevels = {

};

module.exports = winston.createLogger({
    levels: {
        error: 0,
        database: 1,
        warn: 2,
        info: 3,
        verbose: 4,
        debug: 5,
        silly: 6,
        success: 7,
        request: 8,
        params: 9,
        route: 10
    },
    transports: [

        new (winston.transports.File)({
            name: 'request-file',
            level: "request",
            filename: "logs/request.log",
            maxsize: 1048576,
            maxFiles: 10,
            colorize: false
        }),
        new (winston.transports.File)({
            name: 'error-file',
            filename: 'logs/error.log',
            level: 'error',
            colorize: false
        }),
        new (winston.transports.File)({
            name: 'success-file',
            filename: 'logs/success.log',
            level: 'success',
            maxsize: 1048576,
            maxFiles: 10,
            colorize: false
        }),
        new (winston.transports.File)({
            name: 'database-file',
            filename: 'logs/database.log',
            level: 'database',
            colorize: false
        }),
        new (winston.transports.File)({
            name: 'request-route-file',
            filename: 'logs/request-route.log',
            level: 'route',
            colorize: false
        }),
        new (winston.transports.File)({
            name: 'request-params-file',
            filename: 'logs/request-params.log',
            level: 'params',
            colorize: false
        })
    ]
});