module.exports = function (sequelize, DataTypes) {
    var users = sequelize.define('users', {
        id_user: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false
        },
        nickname: {
            type: DataTypes.STRING,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            allowNull: true
        },
        photo: {
            type: DataTypes.STRING,
            allowNull: false,
        },

        is_reset_password: {
            type: DataTypes.ENUM('Y', 'N'),
            allowNull: false,
            defaultValue: 'N'
        },
        platform: {
            type: DataTypes.ENUM('ANDROID', 'IOS'),
            allowNull: false
        },
        region: {
            type: DataTypes.STRING,
            allowNull: false
        },
        creation_date: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue:  sequelize.fn('NOW')
        },
        active: {
            type: DataTypes.ENUM('Y', 'N'),
            allowNull: false,
            defaultValue: 'Y'
        }
    },{
        tableName: 'users',
        timestamps: false,
        classMethods: {
            associate: function (models) {
       
            }
        },indexes: [
            {
                unique: true,
                fields: ['nickname']
            }
        ]
    });
    return users;

}