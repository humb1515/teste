var app = require("./config/express")();
var port = process.env.PORT || 80;
var models = require("./models");

models.sequelize.sync().then(function () {
  app.listen(port, function () {
    console.log("Server ON at port %s database: development", port);
  });
});

