var app = require("./config/express")();
var port = process.env.PORT || 3001;
var models = require("./models");

models.sequelize.sync().then(function () {
  app.listen(port, function () {
    console.log("Server ON at port %s databae: %s", port, process.env.NODE_ENV);
  });
});

