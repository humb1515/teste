var fs= require('fs');

function imageProcess(){
}

imageProcess.prototype.saveImg = function(request, dado){
    request.pipe(fs.createWriteStream(dado.local + dado.name + '.jpg'))
    .on('finish', function(){
    });
}

module.exports= function(){
    return imageProcess;
}