var jwt = require('jwt-simple'),
 moment = require('moment'),
 secret = "24f5d8e9e2fe990ae7fa6524c4117e14"; //who is the secret

 module.exports ={

    getCurrentTime: function (){
        return moment();
    },

    isTokenValid: function(token, callback){
        if(token){
            try{
                var decoded = jwt.decode(token, secret);
                if(decoded){
                    if(decoded.exp <= this.getCurrentTime()){
                        callback(false, 403 , "Access Denied");
                    }else{
                        callback(true, 200, "Authenticated", decoded.iss);
                    }
                }
            }
            catch(exception){
                callback(false, 401, "Invalid Token");
            }
        }else{
            callback(false, 404 , "Null Token");
        }
    },

    generateToken: function(user, callback){
        user.password = "";
        var expires = moment(this.getCurrentTime().add(10, 'days').valueOf());
        var token = jwt.encode({iss:user, exp:expires}, secret);
        callback(token, expires);
    },

    getUserfromToken: function(request){
        var User =[];
    this.isTokenValid(request.headers.authorization, function(IsValid, code, message,user){
             if(IsValid){
                 User = user
             }else{
                 response.status(code).json({message:message});
             }});
             return  User;
     }

 }